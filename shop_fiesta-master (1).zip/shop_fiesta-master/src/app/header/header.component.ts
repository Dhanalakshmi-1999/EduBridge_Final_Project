import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  userDropdownOpen: boolean = false;

  public totalItem : number = 0;
  public searchTerm !: string;
  cartService: any;
  constructor(private router: Router) { }

  navigateToHome() {
    this.router.navigate(['/home']);
  }
  openUserDropdown() {
    this.userDropdownOpen = !this.userDropdownOpen;
  }
  search(event:any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.cartService.search.next(this.searchTerm);
  }
}
