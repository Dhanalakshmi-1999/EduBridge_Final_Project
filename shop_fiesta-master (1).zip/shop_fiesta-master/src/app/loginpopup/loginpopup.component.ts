import { Component } from '@angular/core';
// import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-loginpopup',
  templateUrl: './loginpopup.component.html',
  styleUrl: './loginpopup.component.css'
})
export class LoginpopupComponent {
  // constructor(public dialogRef: MatDialogRef<LoginpopupComponent>) {}
}
