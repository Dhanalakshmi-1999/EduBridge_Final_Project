export interface Home {
    productname: string;
    description: string;
    price: number;
    image: string;
}