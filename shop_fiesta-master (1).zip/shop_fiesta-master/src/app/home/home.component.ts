import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router) { }
  ngOnInit() { }

  url: string = "../assets/1.jpg";
  url1: string = "../assets/2.jpg";
  url2: string = "../assets/3.jpg";
  url3: string = "../assets/4.jpg";

  filter(category: string) {
    this.router.navigate(['/products'], { queryParams: { category: category } });
  }

  changeImage(event: any) {
    this.url = event.target.src;
    this.url1 = event.target.src;
    this.url2 = event.target.src;
    this.url3 = event.target.src;
  }

  pratnersArray: any = [{
    imgname: "../assets/apple.jpg"
  }, {
    imgname: "../assets/ant.jpg"
  }, {
    imgname: "../assets/amd.jpg"
  }, {
    imgname: "../assets/apple.jpg"
  }, {
    imgname: "../assets/ant.jpg"
  }, {
    imgname: "../assets/apple.jpg"
  }
  ];

  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  };

  policyOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: false,
    navSpeed: 700,
    navText: ['<i class="fa fa-caret-left"></i>', '<i class="fa fa-caret-right"></i>'],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },
    nav: true
  }

}
