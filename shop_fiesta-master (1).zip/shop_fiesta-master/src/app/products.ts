export interface Products {
    productname:string;
    description:string;
    price:number;
    image:string;
}