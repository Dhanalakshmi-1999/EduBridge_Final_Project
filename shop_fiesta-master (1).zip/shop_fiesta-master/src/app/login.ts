export class login {
    username!:string;
    password!:string;
}
