export class RegUser {
    fullname!: string;
    email!: string;
    newPassword!: string;
    address!: string;
}
